package data

// TODO: Bundle the folder instead of the file when we have language support.
//go:generate go run ../../fyne bundle -package settings -o ../settings/bundled.go assets/appearance.svg
