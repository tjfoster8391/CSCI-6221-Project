package data

//go:generate go run ../../fyne bundle -package data -o bundled.go assets

// FyneScene contains the full fyne logo with background design
var FyneScene = resourceLogoPng
